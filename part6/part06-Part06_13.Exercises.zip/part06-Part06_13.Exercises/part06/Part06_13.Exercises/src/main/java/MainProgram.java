
public class MainProgram {

    // update here your exercise progress
    public static int partsCompleted() {
        return 2;
    }
}
